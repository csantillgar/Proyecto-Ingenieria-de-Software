package com.example.movie_reco_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
