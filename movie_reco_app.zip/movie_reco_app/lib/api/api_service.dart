// lib/api/api_service.dart

import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/material.dart';

class ApiService {
  // ATENCIÓN: Se utiliza localhost:8080/api para desarrollo en Chrome.
  final String _baseUrl = 'http://localhost:8080/api';
  String? _jwtToken;

  void setToken(String token) {
    _jwtToken = token;
    debugPrint("Token JWT establecido: ${_jwtToken?.isNotEmpty == true}");
  }

  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    if (_jwtToken != null)
      'Authorization': 'Bearer $_jwtToken', // Envío del token JWT
  };

  // Método GET corregido para manejar queryParams (Usado por CatalogProvider)
  Future<http.Response> get(String endpoint, {Map<String, dynamic>? queryParams}) {
    // Construir la URI completa, incluyendo la base URL
    Uri uri = Uri.parse('$_baseUrl/$endpoint');

    // Si hay parámetros de consulta, añadirlos a la URI
    if (queryParams != null && queryParams.isNotEmpty) {
      uri = uri.replace(queryParameters: queryParams.map(
            (key, value) => MapEntry(key, value.toString()),
      ));
    }

    return http.get(uri, headers: _headers);
  }

  // Método POST (Usado para Login y para enviar Valoraciones)
  Future<http.Response> post(String endpoint, Map<String, dynamic> body) {
    final uri = Uri.parse('$_baseUrl/$endpoint');
    return http.post(
      uri,
      headers: _headers,
      body: jsonEncode(body),
    );
  }
}