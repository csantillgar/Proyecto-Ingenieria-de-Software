// lib/components/filter_dialog.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/catalog_provider.dart';

// Lista de géneros de prueba (basado en catálogos típicos de seeding)
const List<String> availableGenres = [
  'Todos',
  'Acción',
  'Aventura',
  'Ciencia Ficción',
  'Drama',
  'Comedia',
  'Terror',
  'Romance'
];

Future<void> showFilterDialog(BuildContext context) async {
  // Obtener el estado actual del Provider (lectura, listen: false)
  final catalogProvider = Provider.of<CatalogProvider>(context, listen: false);

  // Inicializar los valores del diálogo con los filtros actualmente aplicados
  String? selectedGenre = catalogProvider.currentGenre;
  TextEditingController yearController = TextEditingController(
    text: catalogProvider.currentMinYear?.toString() ?? '',
  );

  return showDialog<void>(
    context: context,
    builder: (BuildContext dialogContext) {
      return AlertDialog(
        title: const Text('Filtrar Catálogo (RF-04)'),
        content: SingleChildScrollView(
          child: ListBody(
            children: <Widget>[
              // 1. Selector de Género
              DropdownButtonFormField<String>(
                value: selectedGenre,
                decoration: const InputDecoration(labelText: 'Género'),
                items: availableGenres.map((String genre) {
                  return DropdownMenuItem<String>(
                    value: genre == 'Todos' ? null : genre,
                    child: Text(genre),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  // Actualiza el valor temporalmente dentro del diálogo
                  selectedGenre = newValue;
                },
              ),
              const SizedBox(height: 20),

              // 2. Campo de Año Mínimo
              TextField(
                controller: yearController,
                decoration: const InputDecoration(
                  labelText: 'Año Mínimo (Ej. 2000)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text('Cancelar'),
            onPressed: () {
              Navigator.of(dialogContext).pop();
            },
          ),
          TextButton(
            child: const Text('Aplicar Filtros'),
            onPressed: () {
              int? minYear;
              // Intenta parsear el año, si falla, es nulo
              try {
                if (yearController.text.isNotEmpty) {
                  minYear = int.parse(yearController.text);
                }
              } catch (_) {
                // Manejar error de formato de número si es necesario
              }

              // Aplicar filtros al Provider
              catalogProvider.setFilters(
                genre: selectedGenre,
                minYear: minYear,
              );

              Navigator.of(dialogContext).pop();
            },
          ),
        ],
      );
    },
  );
}