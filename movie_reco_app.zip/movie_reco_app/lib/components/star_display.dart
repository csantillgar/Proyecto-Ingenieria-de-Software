// lib/components/star_display.dart
import 'package:flutter/material.dart';

class StarDisplay extends StatelessWidget {
  final double value;
  final double size;

  const StarDisplay({super.key, this.value = 0, this.size = 18});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (index) {
        return Icon(
          index < value.round() ? Icons.star : Icons.star_border,
          color: Colors.amber,
          size: size,
        );
      }),
    );
  }
}