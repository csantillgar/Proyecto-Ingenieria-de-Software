import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'api/api_service.dart'; // <--- IMPORTANTE: Importar esto
import 'providers/auth_provider.dart';
import 'providers/catalog_provider.dart';
import 'providers/movie_provider.dart';
import 'providers/rating_provider.dart';
import 'providers/recommendation_provider.dart';
import 'screens/login_screen.dart';
import 'screens/main_navigation_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // 1. Creamos el servicio aquí mismo para poder pasarlo
    final apiService = ApiService();

    // Color principal de la marca (Rojo Netflix)
    final Color primaryColor = const Color(0xFFE50914);

    return MultiProvider(
      providers: [
        // 2. Pasamos 'apiService' a cada uno, porque tus archivos antiguos lo piden
        ChangeNotifierProvider(create: (_) => AuthProvider(apiService)),
        ChangeNotifierProvider(create: (_) => CatalogProvider(apiService)),
        ChangeNotifierProvider(create: (_) => MovieProvider(apiService)),
        ChangeNotifierProvider(create: (_) => RatingProvider(apiService)),
        ChangeNotifierProvider(create: (_) => RecommendationProvider(apiService)),
      ],
      child: Consumer<AuthProvider>(
        builder: (context, auth, _) {
          return MaterialApp(
            title: 'Lumière Films',
            debugShowCheckedModeBanner: false,

            // --- TEMA OSCURO (Lumière Films) ---
            theme: ThemeData.dark().copyWith(
              scaffoldBackgroundColor: const Color(0xFF121212),
              primaryColor: primaryColor,
              appBarTheme: const AppBarTheme(
                backgroundColor: Color(0xFF121212),
                elevation: 0,
                centerTitle: true,
                titleTextStyle: TextStyle(
                    fontFamily: 'Serif',
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white
                ),
                iconTheme: IconThemeData(color: Colors.white),
              ),
              colorScheme: const ColorScheme.dark().copyWith(
                primary: primaryColor,
                secondary: Colors.amber,
              ),
              inputDecorationTheme: InputDecorationTheme(
                filled: true,
                fillColor: const Color(0xFF2C2C2C),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
                hintStyle: const TextStyle(color: Colors.grey),
              ),
              elevatedButtonTheme: ElevatedButtonThemeData(
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  textStyle: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              textSelectionTheme: TextSelectionThemeData(
                cursorColor: primaryColor,
                selectionColor: primaryColor.withOpacity(0.4),
                selectionHandleColor: primaryColor,
              ),
            ),

            // Lógica de navegación
            home: auth.isAuthenticated ? const MainNavigationScreen() : const LoginScreen(),
          );
        },
      ),
    );
  }
}