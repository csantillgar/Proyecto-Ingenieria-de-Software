// lib/models/movie_model.dart

import 'dart:convert';

// 1. Modelo para la Película (Mapea MovieEntity)
class MovieModel {
  final String id;
  final String title;
  final int? releaseYear;
  final String? overview;
  final double? avgRating;
  final List<String>? genres;
  final List<String>? tags;
  // Campo para la imagen
  final String? posterUrl;

  MovieModel({
    required this.id,
    required this.title,
    this.releaseYear,
    this.overview,
    this.avgRating,
    this.genres,
    this.tags,
    this.posterUrl,
  });

  factory MovieModel.fromJson(Map<String, dynamic> json) {
    return MovieModel(
      id: json['id'],
      title: json['title'],
      releaseYear: json['releaseYear'] as int?,
      overview: json['overview'] as String?,
      avgRating: (json['avgRating'] as num?)?.toDouble(),
      genres: json['genres'] is List ? List<String>.from(json['genres']) : null,
      tags: json['tags'] is List ? List<String>.from(json['tags']) : null,

      // --- ESTA ES LA LÍNEA QUE FALTABA ---
      // Conecta el JSON que viene del backend con tu variable
      posterUrl: json['posterUrl'] as String?,
      // ------------------------------------
    );
  }
}

// 2. Modelo para el Item de Recomendación (Mapea MovieWithScore)
class RecommendationItemModel {
  final MovieModel movie;
  final double score; // Puntuación dada por el motor (RF-06)

  RecommendationItemModel({required this.movie, required this.score});

  factory RecommendationItemModel.fromJson(Map<String, dynamic> json) {
    return RecommendationItemModel(
      // Se espera que el objeto 'movie' esté anidado dentro del item de recomendación
      movie: MovieModel.fromJson(json['movie']),
      score: (json['score'] as num).toDouble(),
    );
  }
}