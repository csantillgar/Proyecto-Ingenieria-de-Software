// lib/models/user_model.dart

import 'dart:convert';

// Mapea la respuesta del login (POST /api/auth/login)
class LoginResponseModel {
  final String token;
  LoginResponseModel({required this.token});

  factory LoginResponseModel.fromJson(Map<String, dynamic> json) {
    return LoginResponseModel(token: json['token']);
  }
}

// Mapea la respuesta del perfil (GET /api/account/me)
class UserProfileModel {
  final String id;
  final String email;
  final String name;
  final String role;

  UserProfileModel({required this.id, required this.email, required this.name, required this.role});

  factory UserProfileModel.fromJson(Map<String, dynamic> json) {
    return UserProfileModel(
      id: json['id'],
      email: json['email'],
      name: json['name'],
      role: json['role'],
    );
  }
}