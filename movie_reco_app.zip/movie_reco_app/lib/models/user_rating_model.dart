class UserRatingModel {
  final String movieId;
  final String movieTitle;
  final int score;
  final String? comment;

  UserRatingModel({
    required this.movieId,
    required this.movieTitle,
    required this.score,
    this.comment,
  });

  factory UserRatingModel.fromJson(Map<String, dynamic> json) {
    return UserRatingModel(
      movieId: json['movieId'],
      movieTitle: json['movieTitle'] ?? 'Sin título',
      score: json['score'] ?? 0,
      comment: json['comment'],
    );
  }
}