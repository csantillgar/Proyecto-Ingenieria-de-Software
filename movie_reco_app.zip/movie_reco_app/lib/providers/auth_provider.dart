import 'package:flutter/material.dart';
import '../api/api_service.dart';
import '../models/user_model.dart';
import 'dart:convert';

class AuthProvider extends ChangeNotifier {
  final ApiService apiService;
  UserProfileModel? _user;

  AuthProvider(this.apiService);

  bool get isAuthenticated => _user != null;
  UserProfileModel? get user => _user;

  // 1. Login
  Future<bool> login(String email, String password) async {
    try {
      final response = await apiService.post('auth/login', {
        'email': email,
        'password': password,
      });

      if (response.statusCode == 200) {
        final loginData = LoginResponseModel.fromJson(jsonDecode(response.body));
        apiService.setToken(loginData.token);
        await fetchUserProfile(); // <--- Esto carga el nombre y el correo
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error en login: $e');
      return false;
    }
  }

  // 2. Registro (MEJORADO: Auto-Login)
  Future<bool> register(String name, String email, String password) async {
    try {
      final response = await apiService.post('auth/register', {
        'name': name,
        'email': email,
        'password': password,
      });

      if (response.statusCode == 200 || response.statusCode == 201) {
        // TRUCO: Si el registro es exitoso, hacemos login automáticamente
        // para obtener el Token y los datos del usuario inmediatamente.
        return await login(email, password);
      } else {
        debugPrint('Error registro: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      debugPrint('Excepción registro: $e');
      return false;
    }
  }

  // 3. Obtener perfil
  Future<void> fetchUserProfile() async {
    try {
      final response = await apiService.get('auth/me');

      if (response.statusCode == 200) {
        // Usamos utf8.decode para que salgan bien las tildes y ñ
        _user = UserProfileModel.fromJson(jsonDecode(utf8.decode(response.bodyBytes)));
        notifyListeners();
      } else {
        logout();
      }
    } catch (e) {
      debugPrint('Error fetchUserProfile: $e');
    }
  }

  // 4. Cerrar sesión
  void logout() {
    _user = null;
    apiService.setToken('');
    notifyListeners();
  }
}