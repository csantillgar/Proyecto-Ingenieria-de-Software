// lib/providers/catalog_provider.dart

import 'package:flutter/material.dart';
import 'dart:convert';
import '../api/api_service.dart';
import '../models/movie_model.dart';
// import 'package:http/http.dart' as http; // No es necesario si usas ApiService

class CatalogProvider extends ChangeNotifier {
  final ApiService apiService;
  List<MovieModel> _movies = [];
  bool _isLoading = false;

  // Estado para los filtros (RF-04)
  String? _currentGenre;
  int? _currentMinYear;

  CatalogProvider(this.apiService);

  List<MovieModel> get movies => _movies;
  bool get isLoading => _isLoading;
  String? get currentGenre => _currentGenre;
  int? get currentMinYear => _currentMinYear;

  // Método para aplicar filtros y recargar
  void setFilters({String? genre, int? minYear}) {
    _currentGenre = genre;
    _currentMinYear = minYear;
    fetchCatalog();
  }

  // Método para forzar la recarga (útil después de valorar una película)
  void loadCatalog() {
    fetchCatalog();
  }

  // Lógica para obtener el catálogo filtrable (RF-04)
  Future<void> fetchCatalog() async {
    _isLoading = true;
    notifyListeners();

    // Construir la URL con parámetros de filtro
    final Map<String, dynamic> queryParams = {};

    // 1. Filtro de GÉNERO
    if (_currentGenre != null && _currentGenre!.isNotEmpty) {
      queryParams['genre'] = _currentGenre;
    }

    // 2. Filtro de AÑO (CORRECCIÓN CRÍTICA AQUÍ)
    if (_currentMinYear != null) {
      // ANTES: queryParams['minYear'] = ... (ERROR)
      // AHORA: Usamos 'fromYear' que es lo que espera Spring Boot
      queryParams['fromYear'] = _currentMinYear.toString();
    }

    String endpoint = 'movies';

    try {
      final response = await apiService.get(endpoint, queryParams: queryParams);

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonResponse = jsonDecode(utf8.decode(response.bodyBytes));

        // Manejo robusto de la respuesta paginada
        if (jsonResponse.containsKey('content')) {
          final List<dynamic> jsonList = jsonResponse['content'];
          _movies = jsonList.map((json) => MovieModel.fromJson(json)).toList();
        } else {
          // Fallback por si el backend devolviera una lista directa en el futuro
          debugPrint('Formato de respuesta inesperado (no tiene content)');
          _movies = [];
        }

        debugPrint('Catálogo cargado: ${_movies.length} películas. Filtros: $queryParams');
      } else {
        debugPrint('Error al cargar catálogo: ${response.statusCode}');
        _movies = [];
      }
    } catch (e) {
      debugPrint('Excepción durante fetchCatalog: $e');
      _movies = [];
    }

    _isLoading = false;
    notifyListeners();
  }
}