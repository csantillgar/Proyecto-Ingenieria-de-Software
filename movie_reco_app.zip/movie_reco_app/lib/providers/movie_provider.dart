// lib/providers/movie_provider.dart

import 'package:flutter/material.dart';
import 'dart:convert';
import '../api/api_service.dart';
import '../models/movie_model.dart';

class MovieProvider extends ChangeNotifier {
  final ApiService apiService;

  MovieProvider(this.apiService);

  // Método para obtener una película por su ID (la información más reciente)
  Future<MovieModel?> fetchMovieById(String movieId) async {
    try {
      // Endpoint: GET /api/movies/{id}
      final response = await apiService.get('movies/$movieId');

      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(utf8.decode(response.bodyBytes));
        return MovieModel.fromJson(jsonResponse);
      } else {
        debugPrint('Error al cargar detalle de película: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      debugPrint('Excepción durante fetchMovieById: $e');
      return null;
    }
  }
}