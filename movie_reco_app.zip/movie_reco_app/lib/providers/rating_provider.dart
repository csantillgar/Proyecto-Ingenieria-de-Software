// lib/providers/rating_provider.dart

import 'package:flutter/material.dart';
import '../api/api_service.dart';
import 'dart:convert';
// Importación necesaria para el nuevo modelo de reseñas
import '../models/user_rating_model.dart';

class RatingProvider extends ChangeNotifier {
  final ApiService apiService;

  // Lista local para guardar las reseñas del usuario
  List<UserRatingModel> _myRatings = [];

  RatingProvider(this.apiService);

  // Getter para acceder a las reseñas desde la UI
  List<UserRatingModel> get myRatings => _myRatings;

  // Implementación de RF-05: Enviar la valoración al backend
  Future<bool> submitRating({
    required String userId,
    required String movieId,
    required int score,
    String? comment,
  }) async {
    final Map<String, dynamic> body = {
      'userId': userId,
      'score': score,
      if (comment != null && comment.isNotEmpty)
        'comment': comment,
    };

    try {
      final response = await apiService.post('ratings/by-movie/$movieId', body);
      if (response.statusCode == 200 || response.statusCode == 201) {
        debugPrint('Valoración enviada exitosamente para Movie ID: $movieId');
        return true;
      } else {
        debugPrint('Error al enviar valoración: ${response.statusCode}');
        debugPrint('Respuesta del cuerpo: ${response.body}');
        return false;
      }
    } catch (e) {
      debugPrint('Excepción al enviar valoración: $e');
      return false;
    }
  }

  // Implementación de RF-06: Persistencia (Verificar si ya votó)
  Future<int> checkUserRating(String userId, String movieId) async {
    try {
      final response = await apiService.get('ratings/check?userId=$userId&movieId=$movieId');

      if (response.statusCode == 200) {
        final json = jsonDecode(utf8.decode(response.bodyBytes));
        return json['score'] ?? 0;
      } else {
        return 0;
      }
    } catch (e) {
      debugPrint('Error verificando rating: $e');
      return 0;
    }
  }

  // --- NUEVA FUNCIONALIDAD: Obtener historial de reseñas ---
  Future<void> fetchMyRatings(String userId) async {
    try {
      // Llamamos al endpoint que devuelve la lista de DTOs con título
      final response = await apiService.get('ratings/by-user/$userId');

      if (response.statusCode == 200) {
        final List<dynamic> jsonList = jsonDecode(utf8.decode(response.bodyBytes));

        // Convertimos el JSON a nuestra lista de objetos UserRatingModel
        _myRatings = jsonList.map((json) => UserRatingModel.fromJson(json)).toList();

        // Avisamos a la pantalla para que se redibuje
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Error cargando mis reseñas: $e');
      _myRatings = []; // Limpiamos en caso de error
      notifyListeners();
    }
  }
}