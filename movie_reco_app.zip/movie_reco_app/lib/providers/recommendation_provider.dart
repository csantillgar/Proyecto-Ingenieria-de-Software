// lib/providers/recommendation_provider.dart

import 'package:flutter/material.dart';
import 'dart:convert';
import '../api/api_service.dart';
import '../models/movie_model.dart'; // Requiere el archivo de modelos del Paso 2.2

class RecommendationProvider extends ChangeNotifier {
  final ApiService apiService;
  List<RecommendationItemModel> _recommendations = [];
  bool _isLoading = false;

  RecommendationProvider(this.apiService);

  List<RecommendationItemModel> get recommendations => _recommendations;
  bool get isLoading => _isLoading;

  // Implementación de RF-06: Llama al motor de recomendación del backend
  Future<void> fetchRecommendations(String userId) async {
    _isLoading = true;
    notifyListeners();

    try {
      // Endpoint: GET /api/v1/users/{id}/recommendations
      final response = await apiService.get('v1/users/$userId/recommendations?k=10');

      if (response.statusCode == 200) {
        final List<dynamic> jsonList = jsonDecode(utf8.decode(response.bodyBytes));

        _recommendations = jsonList
            .map((json) => RecommendationItemModel.fromJson(json))
            .toList();

        debugPrint('Recomendaciones cargadas: ${_recommendations.length}');
      } else {
        debugPrint('Error al cargar recomendaciones: ${response.statusCode}');
        _recommendations = [];
      }
    } catch (e) {
      debugPrint('Excepción durante fetchRecommendations: $e');
      _recommendations = [];
    }

    _isLoading = false;
    notifyListeners();
  }
}