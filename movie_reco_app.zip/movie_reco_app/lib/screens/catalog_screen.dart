import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/movie_model.dart';
import '../providers/catalog_provider.dart';
import '../providers/auth_provider.dart';
import 'movie_detail_screen.dart';
import 'my_ratings_screen.dart';
import 'login_screen.dart';
import '../components/filter_dialog.dart';

class CatalogScreen extends StatefulWidget {
  const CatalogScreen({super.key});

  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = Provider.of<CatalogProvider>(context, listen: false);
      if (provider.movies.isEmpty) {
        provider.fetchCatalog();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final user = authProvider.user;
    final catalogProvider = Provider.of<CatalogProvider>(context);

    return Scaffold(
      // Drawer (Menú Lateral) igual que antes
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(user?.name ?? 'Usuario'),
              accountEmail: Text(user?.email ?? 'correo@ejemplo.com'),
              currentAccountPicture: const CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(Icons.person, size: 40, color: Colors.indigo),
              ),
              decoration: const BoxDecoration(color: Color(0xFF151515)), // Color casi negro
            ),
            ListTile(
              leading: const Icon(Icons.star_half, color: Colors.amber),
              title: const Text('Mis Reseñas'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const MyRatingsScreen()));
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.exit_to_app, color: Colors.redAccent),
              title: const Text('Cerrar Sesión'),
              onTap: () {
                Navigator.pop(context);
                Provider.of<AuthProvider>(context, listen: false).logout();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                      (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        ),
      ),

      // --- CUERPO PRINCIPAL CON SCROLL AVANZADO (SLIVERS) ---
      body: CustomScrollView(
        slivers: [
          // 1. CABECERA EXPANDIBLE (HERO HEADER)
          SliverAppBar(
            expandedHeight: 180.0, // Altura cuando está desplegado
            floating: false,
            pinned: true, // Se queda fija arriba al hacer scroll
            backgroundColor: const Color(0xFF121212),
            flexibleSpace: FlexibleSpaceBar(
              centerTitle: true,
              title: const Text(
                'Catálogo',
                style: TextStyle(
                  fontFamily: 'Serif', // Misma fuente elegante del Login
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  shadows: [Shadow(color: Colors.black, blurRadius: 10)],
                ),
              ),
              background: Stack(
                fit: StackFit.expand,
                children: [
                  // Imagen de fondo temática (Cintas de película, luces...)
                  Image.network(
                    'https://images.unsplash.com/photo-1517604931442-71053e68cc23?q=80&w=2070&auto=format&fit=crop',
                    fit: BoxFit.cover,
                  ),
                  // Degradado para que el texto se lea bien
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          Colors.black.withOpacity(0.8),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.search),
                onPressed: () {
                  showSearch(context: context, delegate: MovieSearchDelegate(catalogProvider.movies));
                },
              ),
              IconButton(
                icon: const Icon(Icons.filter_list),
                onPressed: () => showFilterDialog(context),
              ),
            ],
          ),

          // 2. CONTENIDO (GRILLA)
          if (catalogProvider.isLoading)
            const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator(color: Color(0xFFE50914))),
            )
          else if (catalogProvider.movies.isEmpty)
            const SliverFillRemaining(
              child: Center(child: Text('No hay películas disponibles.', style: TextStyle(color: Colors.white54))),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.all(16.0),
              // Usamos SliverGrid en lugar de GridView
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 200, // Ancho máximo de tarjeta (Responsive)
                  childAspectRatio: 0.65,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                delegate: SliverChildBuilderDelegate(
                      (context, index) {
                    final movie = catalogProvider.movies[index];
                    return MovieGridCard(movie: movie);
                  },
                  childCount: catalogProvider.movies.length,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// (La clase MovieGridCard y MovieSearchDelegate se mantienen igual que la última vez,
//  ya están perfectas con su diseño de póster)
class MovieGridCard extends StatelessWidget {
  final MovieModel movie;
  const MovieGridCard({super.key, required this.movie});

  @override
  Widget build(BuildContext context) {
    final Color placeholderColor = Colors.primaries[movie.title.length % Colors.primaries.length].shade800;

    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (_) => MovieDetailScreen(movie: movie)));
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: const Color(0xFF1E1E1E),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 6, offset: const Offset(0, 4))],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                flex: 4,
                child: Container(
                  color: Colors.black,
                  child: movie.posterUrl != null && movie.posterUrl!.isNotEmpty
                      ? Image.network(
                    movie.posterUrl!,
                    fit: BoxFit.cover,
                    errorBuilder: (ctx, err, stack) => _buildPlaceholder(placeholderColor),
                  )
                      : _buildPlaceholder(placeholderColor),
                ),
              ),
              Expanded(
                flex: 2,
                child: Container(
                  color: const Color(0xFF252525),
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(movie.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.white)),
                      Row(
                        children: [
                          const Icon(Icons.star, size: 14, color: Colors.amber),
                          const SizedBox(width: 4),
                          Text(movie.avgRating != null ? movie.avgRating!.toStringAsFixed(1) : "-", style: const TextStyle(fontSize: 12, color: Colors.grey)),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  Widget _buildPlaceholder(Color color) => Container(color: color, child: const Center(child: Icon(Icons.movie, size: 40, color: Colors.white30)));
}

class MovieSearchDelegate extends SearchDelegate {
  final List<MovieModel> movies;
  MovieSearchDelegate(this.movies);
  @override ThemeData appBarTheme(BuildContext context) => Theme.of(context).copyWith(appBarTheme: Theme.of(context).appBarTheme.copyWith(backgroundColor: const Color(0xFF1F1F1F)), inputDecorationTheme: const InputDecorationTheme(border: InputBorder.none, hintStyle: TextStyle(color: Colors.grey)));
  @override String get searchFieldLabel => 'Buscar...';
  @override List<Widget>? buildActions(BuildContext context) => [if (query.isNotEmpty) IconButton(icon: const Icon(Icons.clear), onPressed: () => query = '')];
  @override Widget? buildLeading(BuildContext context) => IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => close(context, null));
  @override Widget buildResults(BuildContext context) => _buildGrid();
  @override Widget buildSuggestions(BuildContext context) => _buildGrid();
  Widget _buildGrid() {
    final filtered = movies.where((m) => m.title.toLowerCase().contains(query.toLowerCase())).toList();
    if (filtered.isEmpty) return const Center(child: Text('No hay resultados', style: TextStyle(color: Colors.grey)));
    return GridView.builder(padding: const EdgeInsets.all(16), itemCount: filtered.length, gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 200, childAspectRatio: 0.65, crossAxisSpacing: 16, mainAxisSpacing: 16), itemBuilder: (ctx, i) => MovieGridCard(movie: filtered[i]));
  }
}