// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/recommendation_provider.dart';
import 'movie_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Estado para asegurar que la carga de datos ocurra solo una vez

  @override
  void initState() {
    super.initState();
    // Usa addPostFrameCallback para esperar a que el frame inicial termine
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadData();
    });
  }

  // Llama al RecommendationProvider para obtener datos
  void _loadData() {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final userId = authProvider.user?.id; // Obtenemos el ID del usuario logueado

    if (userId != null) {
      Provider.of<RecommendationProvider>(context, listen: false)
          .fetchRecommendations(userId);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Usamos Consumer para escuchar los cambios del AuthProvider y RecommendationProvider
    return Consumer<AuthProvider>(
      builder: (context, authProvider, child) {
        final userName = authProvider.user?.name ?? 'Usuario';

        return Scaffold(
          appBar: AppBar(
            title: Text('🎬 Recomendaciones para ${userName}'),
            actions: [
              IconButton(
                icon: const Icon(Icons.refresh),
                onPressed: _loadData, // Botón para recargar
              ),
              IconButton(
                icon: const Icon(Icons.logout),
                onPressed: () => authProvider.logout(), // Cierra sesión (RF-02)
              ),
            ],
          ),
          body: Consumer<RecommendationProvider>(
            builder: (context, recoProvider, child) {
              if (recoProvider.isLoading) {
                return const Center(child: CircularProgressIndicator());
              }

              if (recoProvider.recommendations.isEmpty) {
                // Mensaje de cold-start o si el motor no retorna nada
                return const Center(
                  child: Padding(
                    padding: EdgeInsets.all(30.0),
                    child: Text(
                      'No hay recomendaciones disponibles. ¡Valora algunas películas para ayudar al motor!',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  ),
                );
              }

              // Muestra la lista de recomendaciones (RF-06)
              return ListView.builder(
                itemCount: recoProvider.recommendations.length,
                itemBuilder: (context, index) {
                  final item = recoProvider.recommendations[index];
                  return ListTile(
                    leading: const Icon(Icons.movie_filter),
                    title: Text(item.movie.title),
                    subtitle: Text('Score: ${item.score.toStringAsFixed(2)} | Año: ${item.movie.releaseYear ?? 'N/A'}'),
                    // IMPLEMENTACIÓN DE LA NAVEGACIÓN
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => MovieDetailScreen(movie: item.movie),
                        ),
                      );
                    },
                  );
                },
              );
            },
          ),
        );
      },
    );
  }
}