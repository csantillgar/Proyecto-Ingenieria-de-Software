// lib/screens/main_navigation_screen.dart

import 'package:flutter/material.dart';
// 1. ELIMINAMOS 'home_screen.dart'
// import 'home_screen.dart';
// 2. IMPORTAMOS LA NUEVA PANTALLA
import 'recommendation_screen.dart';
import 'catalog_screen.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _selectedIndex = 0;

  // Lista de pantallas a mostrar
  static const List<Widget> _widgetOptions = <Widget>[
    RecommendationScreen(), // <--- 3. USAMOS LA NUEVA PANTALLA AQUÍ
    CatalogScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 4. ¡¡IMPORTANTE!! HEMOS BORRADO LA APPBAR DE AQUÍ.
      // Como RecommendationScreen y CatalogScreen ya tienen su propia AppBar
      // y su propio Drawer, no necesitamos una aquí. Si la dejáramos,
      // saldría el título antiguo "Recomendaciones para..." y no saldría el menú.

      // Muestra la pantalla seleccionada
      body: _widgetOptions.elementAt(_selectedIndex),

      // Barra de navegación inferior
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.star),
            label: 'Para ti', // Cambié el texto para que coincida con el nuevo diseño
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Catálogo',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Theme.of(context).primaryColor,
        onTap: _onItemTapped,
      ),
    );
  }
}