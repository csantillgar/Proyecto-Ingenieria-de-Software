// lib/screens/movie_detail_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/movie_model.dart';
import '../providers/auth_provider.dart';
import '../providers/rating_provider.dart';
import '../providers/movie_provider.dart';
import '../providers/catalog_provider.dart';
import '../providers/recommendation_provider.dart';

class MovieDetailScreen extends StatefulWidget {
  final MovieModel movie;

  const MovieDetailScreen({super.key, required this.movie});

  @override
  State<MovieDetailScreen> createState() => _MovieDetailScreenState();
}

class _MovieDetailScreenState extends State<MovieDetailScreen> {
  MovieModel? _currentMovie;
  int _currentScore = 0;
  final TextEditingController _commentController = TextEditingController();

  // Controla el estado visual de "Ya valorado"
  bool _hasRatedSuccessfully = false;
  // Para mostrar un indicador de carga mientras comprobamos
  bool _isCheckingRating = true;

  @override
  void initState() {
    super.initState();
    _currentMovie = widget.movie;
    // Comprobamos nada más entrar si ya existe valoración
    _checkExistingRating();
  }

  // NUEVA FUNCIÓN: Pregunta al backend si ya valoré esta peli
  Future<void> _checkExistingRating() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final userId = authProvider.user?.id;

    if (userId != null) {
      final ratingProvider = Provider.of<RatingProvider>(context, listen: false);
      // Llamamos al método nuevo del Provider
      final existingScore = await ratingProvider.checkUserRating(userId, _currentMovie!.id);

      if (existingScore > 0 && mounted) {
        setState(() {
          _currentScore = existingScore; // Ponemos la nota que tenía
          _hasRatedSuccessfully = true;  // Bloqueamos la interfaz
          _isCheckingRating = false;
        });
        return;
      }
    }

    if (mounted) {
      setState(() {
        _isCheckingRating = false; // Terminó de comprobar, no había nota
      });
    }
  }

  // Refresca la información local
  Future<void> _refreshMovieData() async {
    final movieProvider = Provider.of<MovieProvider>(context, listen: false);
    final updatedMovie = await movieProvider.fetchMovieById(_currentMovie!.id);

    if (updatedMovie != null && mounted) {
      setState(() {
        _currentMovie = updatedMovie;
      });
    }
  }

  void _submitRating() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final userId = authProvider.user?.id;

    if (userId == null) return;

    if (_currentScore == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor, selecciona una puntuación.')),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Enviando valoración para ${_currentMovie!.title}...')),
    );

    final success = await Provider.of<RatingProvider>(context, listen: false).submitRating(
      userId: userId,
      movieId: _currentMovie!.id,
      score: _currentScore,
      comment: _commentController.text,
    );

    if (success) {
      await _refreshMovieData();

      if (mounted) {
        Provider.of<CatalogProvider>(context, listen: false).fetchCatalog();
        Provider.of<RecommendationProvider>(context, listen: false).fetchRecommendations(userId);
      }

      if (mounted) {
        setState(() {
          _hasRatedSuccessfully = true; // Bloqueamos al instante
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('¡Valoración para ${_currentMovie!.title} enviada con éxito!')),
        );
        _commentController.clear();
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Error al enviar valoración.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final movie = _currentMovie ?? widget.movie;

    return Scaffold(
      appBar: AppBar(title: Text(movie.title)),
      body: _isCheckingRating
          ? const Center(child: CircularProgressIndicator()) // Cargando mientras comprueba
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${movie.title} (${movie.releaseYear ?? 'N/A'})',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            // ... (Resto de la UI igual que antes) ...
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.star, color: Colors.amber, size: 24),
                const SizedBox(width: 4),
                Text('Rating Promedio: ${movie.avgRating?.toStringAsFixed(1) ?? 'N/A'}'),
              ],
            ),
            const Divider(height: 30),
            Text('Sinopsis:', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Text(movie.overview ?? 'No se proporcionó sinopsis.'),
            const Divider(height: 30),

            // Sección de Valoración
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Tu Valoración:', style: Theme.of(context).textTheme.titleLarge),
                if (_hasRatedSuccessfully)
                  const Chip(
                    label: Text("Enviado"),
                    avatar: Icon(Icons.check, color: Colors.white),
                    backgroundColor: Colors.green,
                    labelStyle: TextStyle(color: Colors.white),
                  )
              ],
            ),

            // Slider (Bloqueado si ya existe valoración)
            Slider(
              value: _currentScore.toDouble(),
              min: 0, max: 5, divisions: 5,
              label: _currentScore == 0 ? 'Sin calificar' : _currentScore.toString(),
              onChanged: _hasRatedSuccessfully
                  ? null
                  : (val) => setState(() => _currentScore = val.round()),
            ),
            Center(
                child: Text(_hasRatedSuccessfully
                    ? 'Ya has puntuado: $_currentScore'
                    : 'Puntuación Seleccionada: $_currentScore')
            ),
            const SizedBox(height: 10),

            TextField(
              controller: _commentController,
              enabled: !_hasRatedSuccessfully,
              decoration: const InputDecoration(
                labelText: 'Reseña (Opcional)',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 20),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _hasRatedSuccessfully ? null : _submitRating,
                icon: Icon(_hasRatedSuccessfully ? Icons.check_circle : Icons.send),
                label: Text(_hasRatedSuccessfully ? '¡Película ya valorada!' : 'Enviar Valoración'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _hasRatedSuccessfully ? Colors.green : null,
                  disabledBackgroundColor: Colors.green.withOpacity(0.6),
                  disabledForegroundColor: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}