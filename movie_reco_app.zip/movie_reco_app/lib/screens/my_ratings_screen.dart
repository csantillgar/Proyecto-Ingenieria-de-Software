import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/rating_provider.dart';

class MyRatingsScreen extends StatefulWidget {
  const MyRatingsScreen({super.key});

  @override
  State<MyRatingsScreen> createState() => _MyRatingsScreenState();
}

class _MyRatingsScreenState extends State<MyRatingsScreen> {
  @override
  void initState() {
    super.initState();
    // Cargar reseñas al entrar
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final userId = Provider.of<AuthProvider>(context, listen: false).user?.id;
      if (userId != null) {
        Provider.of<RatingProvider>(context, listen: false).fetchMyRatings(userId);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final ratings = Provider.of<RatingProvider>(context).myRatings;

    return Scaffold(
      appBar: AppBar(title: const Text('Mis Reseñas')),
      body: ratings.isEmpty
          ? const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.rate_review_outlined, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text("Aún no has valorado ninguna película"),
          ],
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: ratings.length,
        itemBuilder: (context, index) {
          final item = ratings[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            elevation: 2,
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.amber,
                child: Text(
                  '${item.score}',
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
              title: Text(
                item.movieTitle,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: item.comment != null && item.comment!.isNotEmpty
                  ? Text('"${item.comment}"', style: const TextStyle(fontStyle: FontStyle.italic))
                  : const Text('Sin comentario', style: TextStyle(color: Colors.grey)),
              trailing: const Icon(Icons.movie, color: Colors.indigo),
            ),
          );
        },
      ),
    );
  }
}