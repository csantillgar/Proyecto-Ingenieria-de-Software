import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/recommendation_provider.dart';
import '../providers/auth_provider.dart';
import '../models/movie_model.dart';
import 'movie_detail_screen.dart';
import 'my_ratings_screen.dart';
import 'login_screen.dart';
import '../components/star_display.dart';

class RecommendationScreen extends StatefulWidget {
  const RecommendationScreen({super.key});

  @override
  State<RecommendationScreen> createState() => _RecommendationScreenState();
}

class _RecommendationScreenState extends State<RecommendationScreen> {

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      if (authProvider.user != null) {
        Provider.of<RecommendationProvider>(context, listen: false)
            .fetchRecommendations(authProvider.user!.id);
      }
    });
  }

  // (El Drawer se mantiene igual que antes)
  Widget _buildDrawer(BuildContext context, user) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            accountName: Text(user?.name ?? 'Usuario'),
            accountEmail: Text(user?.email ?? 'correo@ejemplo.com'),
            currentAccountPicture: const CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.person, size: 40, color: Colors.indigo)),
            decoration: const BoxDecoration(color: Color(0xFF151515)),
          ),
          ListTile(
            leading: const Icon(Icons.star_half, color: Colors.amber),
            title: const Text('Mis Reseñas'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const MyRatingsScreen()));
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.exit_to_app, color: Colors.redAccent),
            title: const Text('Cerrar Sesión'),
            onTap: () {
              Navigator.pop(context);
              Provider.of<AuthProvider>(context, listen: false).logout();
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => const LoginScreen()), (Route<dynamic> route) => false);
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      drawer: _buildDrawer(context, authProvider.user),
      body: CustomScrollView(
        slivers: [
          // 1. CABECERA EXPANDIBLE (PARA TI)
          SliverAppBar(
            expandedHeight: 160.0,
            floating: false,
            pinned: true,
            backgroundColor: const Color(0xFF121212),
            flexibleSpace: FlexibleSpaceBar(
              centerTitle: true,
              title: const Text(
                'Para ti ❤️',
                style: TextStyle(
                  fontFamily: 'Serif',
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  shadows: [Shadow(color: Colors.black, blurRadius: 10)],
                ),
              ),
              background: Stack(
                fit: StackFit.expand,
                children: [
                  // Imagen abstracta roja/oscura
                  Image.network(
                    'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?q=80&w=2070&auto=format&fit=crop',
                    fit: BoxFit.cover,
                  ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Colors.black.withOpacity(0.9)],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 2. LISTA DE RECOMENDACIONES
          Consumer<RecommendationProvider>(
            builder: (context, provider, child) {
              if (provider.isLoading) {
                return const SliverFillRemaining(child: Center(child: CircularProgressIndicator(color: Color(0xFFE50914))));
              }

              if (provider.recommendations.isEmpty) {
                return SliverFillRemaining(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.thumb_up_alt_outlined, size: 80, color: Colors.grey[700]),
                        const SizedBox(height: 16),
                        const Text(
                          'Valora películas para recibir recomendaciones',
                          style: TextStyle(color: Colors.grey, fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                );
              }

              return SliverPadding(
                padding: const EdgeInsets.symmetric(vertical: 8.0),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                        (context, index) {
                      final recommendationItem = provider.recommendations[index];
                      final MovieModel movie = recommendationItem.movie;

                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        color: const Color(0xFF1E1E1E), // Fondo tarjeta oscuro
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        child: InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (_) => MovieDetailScreen(movie: movie)));
                          },
                          borderRadius: BorderRadius.circular(10),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              children: [
                                // Póster pequeño
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Container(
                                    width: 60,
                                    height: 90,
                                    color: Colors.black,
                                    child: movie.posterUrl != null
                                        ? Image.network(movie.posterUrl!, fit: BoxFit.cover)
                                        : const Icon(Icons.movie, color: Colors.white24),
                                  ),
                                ),
                                const SizedBox(width: 16),

                                // Info Película
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        movie.title,
                                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                                      ),
                                      const SizedBox(height: 6),
                                      Row(
                                        children: [
                                          StarDisplay(value: movie.avgRating ?? 0),
                                          const SizedBox(width: 8),
                                          Text(
                                            movie.avgRating != null ? movie.avgRating!.toStringAsFixed(1) : "-",
                                            style: const TextStyle(color: Colors.grey, fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),

                                // Porcentaje de Match
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF1B5E20), // Verde oscuro
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: Colors.greenAccent.withOpacity(0.5)),
                                  ),
                                  child: Text(
                                    "${(recommendationItem.score * 100).toInt()}% Match",
                                    style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                    childCount: provider.recommendations.length,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}