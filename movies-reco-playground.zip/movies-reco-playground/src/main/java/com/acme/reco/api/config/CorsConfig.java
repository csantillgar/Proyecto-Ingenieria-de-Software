package com.acme.reco.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig {
    @Bean
    public WebMvcConfigurer cors() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry r) {
                r.addMapping("/**")
                        // PERMITE TODOS LOS ORÍGENES EN DESARROLLO PARA SOLUCIONAR EL FALLO DE CHROME
                        .allowedOriginPatterns("*")
                        .allowedMethods("*")
                        // Esencial para enviar credenciales (JWT/token)
                        .allowCredentials(true)
                        .allowedHeaders("*");
            }
        };
    }
}
