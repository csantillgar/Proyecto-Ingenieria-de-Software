package com.acme.reco.api.controller;

import com.acme.reco.api.dto.MovieRatingRequest;
import com.acme.reco.api.dto.UserRatingDto; // Asegúrate de tener este DTO creado
import com.acme.reco.api.service.RatingService;
import com.acme.reco.persistence.entity.RatingEntity;
import com.acme.reco.persistence.entity.RatingId;
import com.acme.reco.persistence.repo.MovieJpaRepository; // Importación necesaria
import com.acme.reco.persistence.repo.RatingJpaRepository;
import jakarta.validation.Valid;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/ratings")
public class RatingsController {

    private final RatingJpaRepository ratingsRepo;
    private final RatingService ratingService;
    private final MovieJpaRepository moviesRepo; // 1. Declarado aquí

    // 2. CORRECCIÓN AQUÍ: Añadimos 'MovieJpaRepository moviesRepo' a los argumentos
    public RatingsController(RatingJpaRepository ratingsRepo,
                             RatingService ratingService,
                             MovieJpaRepository moviesRepo) {
        this.ratingsRepo = ratingsRepo;
        this.ratingService = ratingService;
        this.moviesRepo = moviesRepo; // Ahora sí se inicializa correctamente
    }

    /**
     * Crea o Actualiza una valoración.
     * Importante: invalida caches de recomendaciones/similares/estadísticas.
     */
    @PostMapping("/by-movie/{movieId}")
    @CacheEvict(cacheNames = {"recs", "similar", "stats"}, allEntries = true)
    public ResponseEntity<Void> create(
            @PathVariable UUID movieId,
            @Valid @RequestBody MovieRatingRequest body
    ) {
        var r = new RatingEntity();
        r.setId(new RatingId(movieId, body.userId()));
        r.setScore(body.score());
        r.setComment(body.comment());
        r.setTs(Instant.now());

        ratingService.saveAndRecalc(r);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    /**
     * Comprueba si un usuario ya valoró una película.
     */
    @GetMapping("/check")
    public ResponseEntity<RatingEntity> checkRating(
            @RequestParam UUID userId,
            @RequestParam UUID movieId) {

        return ratingService.findExistingRating(userId, movieId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.noContent().build());
    }

    @GetMapping("/by-movie/{movieId}")
    public List<RatingEntity> byMovie(@PathVariable UUID movieId) {
        return ratingsRepo.findAllByIdMovieId(movieId);
    }

    // Método modificado para devolver DTO con título
    @GetMapping("/by-user/{userId}")
    public List<UserRatingDto> byUser(@PathVariable UUID userId) {
        // 1. Obtenemos las valoraciones
        var ratings = ratingsRepo.findAllByIdUserId(userId);

        // 2. Las transformamos al DTO buscando el título de la peli
        return ratings.stream().map(r -> {
            String title = moviesRepo.findById(r.getId().getMovieId())
                    .map(m -> m.getTitle())
                    .orElse("Película desconocida");

            return new UserRatingDto(
                    r.getId().getMovieId(),
                    title,
                    r.getScore(),
                    r.getComment()
            );
        }).collect(Collectors.toList());
    }
}