// UserRatingDto.java
package com.acme.reco.api.dto;

import java.util.UUID;

public record UserRatingDto(
        UUID movieId,
        String movieTitle,
        int score,
        String comment
) {}