// com/acme/reco/api/service/RatingService.java
package com.acme.reco.api.service;

import com.acme.reco.persistence.entity.MovieEntity;
import com.acme.reco.persistence.entity.RatingEntity;
import com.acme.reco.persistence.entity.RatingId; // <-- NUEVA IMPORTACIÓN NECESARIA
import com.acme.reco.persistence.repo.MovieJpaRepository;
import com.acme.reco.persistence.repo.RatingJpaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

@Service
public class RatingService {
    private final RatingJpaRepository ratings;
    private final MovieJpaRepository movies;

    public RatingService(RatingJpaRepository ratings, MovieJpaRepository movies) {
        this.ratings = ratings;
        this.movies = movies;
    }

    // Método para agregar estadísticas (Promedio y conteo)
    public MovieRatingAggregate aggregateForMovie(UUID movieId) {
        Double avg = ratings.avgByMovie(movieId);
        Long cnt   = ratings.countByMovie(movieId);
        return new MovieRatingAggregate(avg == null ? 0.0 : avg, cnt == null ? 0L : cnt);
    }

    // --- NUEVO MÉTODO PARA EL FRONTEND (RF-06 Check) ---
    public Optional<RatingEntity> findExistingRating(UUID userId, UUID movieId) {
        // Usamos el ID compuesto para buscar directamente
        return ratings.findById(new RatingId(movieId, userId));
    }

    @Transactional
    public void saveAndRecalc(RatingEntity r) {
        // 1. LÓGICA DE ACTUALIZACIÓN O INSERCIÓN
        Optional<RatingEntity> existingRating = ratings.findById(r.getId());

        if (existingRating.isPresent()) {
            // A) ACTUALIZAR: Si ya existe, actualizamos los datos
            RatingEntity dbRating = existingRating.get();
            dbRating.setScore(r.getScore());
            dbRating.setComment(r.getComment());
            dbRating.setTs(Instant.now());
            ratings.save(dbRating);
        } else {
            // B) INSERTAR: Si no existe, guardamos el nuevo objeto
            if (r.getTs() == null) {
                r.setTs(Instant.now());
            }
            ratings.save(r);
        }

        // --- Recálculo del promedio ---

        UUID movieId = r.getId().getMovieId();

        // 2. Recalcular las métricas
        MovieRatingAggregate aggregate = aggregateForMovie(movieId);

        // 3. Cargar la película que debe ser actualizada
        MovieEntity movie = movies.findById(movieId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Movie not found after rating submission"));

        // 4. Actualizar los campos en la entidad MovieEntity
        movie.setAvgRating(aggregate.average());
        movie.setRatingsCount((int) aggregate.count());

        // 5. Guardar la película actualizada
        movies.save(movie);
    }

    public record MovieRatingAggregate(double average, long count) {}
}