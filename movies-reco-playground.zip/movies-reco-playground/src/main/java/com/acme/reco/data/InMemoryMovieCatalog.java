package com.acme.reco.data;

import com.acme.reco.domain.model.Movie;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class InMemoryMovieCatalog {

    public static final UUID MATRIX = UUID.fromString("00000000-0000-0000-0000-000000000101");
    public static final UUID INCEPTION = UUID.fromString("00000000-0000-0000-0000-000000000102");
    public static final UUID INTERSTELLAR = UUID.fromString("00000000-0000-0000-0000-000000000103");
    public static final UUID TOY_STORY = UUID.fromString("00000000-0000-0000-0000-000000000104");
    public static final UUID GODFATHER = UUID.fromString("00000000-0000-0000-0000-000000000105");
    public static final UUID SPIRITED_AWAY = UUID.fromString("00000000-0000-0000-0000-000000000106");
    public static final UUID ALIEN = UUID.fromString("00000000-0000-0000-0000-000000000107");
    public static final UUID BLADE_RUNNER = UUID.fromString("00000000-0000-0000-0000-000000000108");

    public List<Movie> load() {
        return List.of(
                new Movie(MATRIX, "The Matrix", 1999,
                        List.of("Science Fiction", "Action"),
                        List.of("simulation", "ai", "hacker"),
                        "A hacker discovers the reality is a simulation.",
                        "https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg"), // URL AÑADIDA

                new Movie(INCEPTION, "Inception", 2010,
                        List.of("Science Fiction", "Thriller"),
                        List.of("dream", "mind", "heist"),
                        "Thieves plant ideas into dreams.",
                        "https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg"), // URL AÑADIDA

                new Movie(INTERSTELLAR, "Interstellar", 2014,
                        List.of("Science Fiction", "Drama"),
                        List.of("space", "time", "blackhole"),
                        "A team travels through a wormhole in space.",
                        "https://image.tmdb.org/t/p/w500/gEU2QniL6E8ahDaX06e8q288UL.jpg"), // URL AÑADIDA

                new Movie(TOY_STORY, "Toy Story", 1995,
                        List.of("Animation", "Family"),
                        List.of("toys", "friendship"),
                        "Toys come to life when humans are away.",
                        "https://image.tmdb.org/t/p/w500/uXDfjJbdP4ijW5hWSBrPrlKpxab.jpg"), // URL AÑADIDA

                new Movie(GODFATHER, "The Godfather", 1972,
                        List.of("Crime", "Drama"),
                        List.of("mafia", "family"),
                        "The aging patriarch of an organized crime dynasty transfers control to his reluctant son.",
                        "https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsRolD1fZdja1.jpg"), // URL AÑADIDA

                new Movie(SPIRITED_AWAY, "Spirited Away", 2001,
                        List.of("Animation", "Fantasy"),
                        List.of("spirits", "magic", "ghibli"),
                        "A girl wanders into a world ruled by gods, witches, and spirits.",
                        "https://image.tmdb.org/t/p/w500/vlOaxsPEXSvrKwWeWHvTQ7RNSGh.jpg"), // URL AÑADIDA

                new Movie(ALIEN, "Alien", 1979,
                        List.of("Horror", "Science Fiction"),
                        List.of("alien", "space", "survival"),
                        "The crew of a commercial spacecraft encounters a deadly lifeform.",
                        "https://image.tmdb.org/t/p/w500/vfrQk5IPloGg1v9Rzbh2Eg3VGyM.jpg"), // URL AÑADIDA

                new Movie(BLADE_RUNNER, "Blade Runner", 1982,
                        List.of("Science Fiction", "Thriller"),
                        List.of("cyberpunk", "androids", "future"),
                        "A blade runner must pursue and terminate four replicants.",
                        "https://image.tmdb.org/t/p/w500/63N9uy8nd9j7Eog2seLZNdnbKmt.jpg") // URL AÑADIDA
        );
    }
}