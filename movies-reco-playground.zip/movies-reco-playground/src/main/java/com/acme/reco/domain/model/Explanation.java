package com.acme.reco.domain.model;

public record Explanation(String text) {}
