package com.acme.reco.domain.model;

public record Filter(String genre, Integer minYear) {}
