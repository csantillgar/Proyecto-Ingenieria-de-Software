package com.acme.reco.persistence.entity;

public enum BillingInterval {
    MONTH
}
