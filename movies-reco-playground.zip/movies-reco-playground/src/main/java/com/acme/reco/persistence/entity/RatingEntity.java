package com.acme.reco.persistence.entity;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "ratings")
public class RatingEntity {

    @EmbeddedId
    private RatingId id;

    private Integer score;

    @Column(length = 4000)
    private String comment;

    private Instant ts;

    // Constructores
    public RatingEntity() {}

    // Getters y Setters
    public RatingId getId() { return id; }
    public void setId(RatingId id) { this.id = id; }

    // Helpers para acceder a los UUIDs directamente (opcional pero útil)
    public void setMovieId(UUID movieId) {
        if (this.id == null) this.id = new RatingId();
        this.id.setMovieId(movieId);
    }
    public void setUserId(UUID userId) {
        if (this.id == null) this.id = new RatingId();
        this.id.setUserId(userId);
    }

    public Integer getScore() { return score; }
    public void setScore(Integer score) { this.score = score; }
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    public Instant getTs() { return ts; }
    public void setTs(Instant ts) { this.ts = ts; }
}
