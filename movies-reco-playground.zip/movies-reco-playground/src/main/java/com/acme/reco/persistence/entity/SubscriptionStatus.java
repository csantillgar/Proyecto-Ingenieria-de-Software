package com.acme.reco.persistence.entity;

public enum SubscriptionStatus {
    ACTIVE,
    CANCELED,
    EXPIRED
}
