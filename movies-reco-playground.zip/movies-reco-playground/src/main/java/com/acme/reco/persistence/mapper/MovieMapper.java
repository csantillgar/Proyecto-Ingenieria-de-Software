package com.acme.reco.persistence.mapper;

import com.acme.reco.domain.model.Movie;
import com.acme.reco.persistence.entity.MovieEntity;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MovieMapper {

    public static Movie toDomain(MovieEntity entity) {
        List<String> genres = entity.getGenresCsv() != null
                ? Arrays.asList(entity.getGenresCsv().split(","))
                : Collections.emptyList();

        List<String> tags = entity.getTagsCsv() != null
                ? Arrays.asList(entity.getTagsCsv().split(","))
                : Collections.emptyList();

        return new Movie(
                entity.getId(),
                entity.getTitle(),
                entity.getReleaseYear(),
                genres,
                tags,
                entity.getOverview(),
                entity.getPosterUrl() // <--- ¡ESTO ES LO QUE FALTABA!
        );
    }
}