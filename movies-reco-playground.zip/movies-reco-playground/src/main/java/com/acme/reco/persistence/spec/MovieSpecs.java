// src/main/java/com/acme/reco/persistence/spec/MovieSpecs.java
package com.acme.reco.persistence.spec;

import com.acme.reco.persistence.entity.MovieEntity;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import jakarta.persistence.criteria.Predicate; // Importación necesaria

public class MovieSpecs {

    // 1. FILTRO DE TÍTULO (q)
    public static Specification<MovieEntity> titleContains(String query) {
        return (root, cq, cb) -> {
            if (!StringUtils.hasText(query)) {
                return cb.conjunction();
            }
            return cb.like(cb.lower(root.get("title")), "%" + query.toLowerCase() + "%");
        };
    }

    // 2. FILTRO DE GÉNERO (genre)
    public static Specification<MovieEntity> genreHas(String genre) {
        return (root, cq, cb) -> {
            if (!StringUtils.hasText(genre)) {
                return cb.conjunction();
            }
            return cb.like(cb.lower(root.get("genresCsv")), "%" + genre.toLowerCase() + "%");
        };
    }

    // 3. FILTRO DE AÑO (fromYear, toYear) - VERSIÓN MÁS SIMPLE Y ROBUSTA
    public static Specification<MovieEntity> yearBetween(Integer fromYear, Integer toYear) {
        return (root, cq, cb) -> {

            if (fromYear == null && toYear == null) {
                return cb.conjunction();
            }

            // Condición base: El año de lanzamiento NO debe ser nulo.
            Predicate finalPredicate = cb.isNotNull(root.get("releaseYear"));

            // Aplicar año mínimo (fromYear)
            if (fromYear != null) {
                finalPredicate = cb.and(
                        finalPredicate,
                        cb.greaterThanOrEqualTo(root.get("releaseYear"), fromYear)
                );
            }

            // Aplicar año máximo (toYear)
            if (toYear != null) {
                finalPredicate = cb.and(
                        finalPredicate,
                        cb.lessThanOrEqualTo(root.get("releaseYear"), toYear)
                );
            }

            return finalPredicate;
        };
    }
}