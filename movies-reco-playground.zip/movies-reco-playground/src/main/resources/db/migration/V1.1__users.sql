-- src/main/resources/db/migration/V1.1__users.sql

insert into users (id, email, password_hash, name, role) values
                                                             -- Contraseña Plana: admin123
                                                             ('c34bc868-1149-48dd-a0a0-decac97c2c3b', 'admin@acme.test', '{noop}admin123', 'Admin User', 'ADMIN'),

                                                             -- Contraseña Plana: userpass
                                                             ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'u1@acme.test', '{noop}userpass', 'User One', 'USER'),

                                                             -- Contraseña Plana: userpass
                                                             ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'u2@acme.test', '{noop}userpass', 'User Two', 'USER'),

                                                             -- Contraseña Plana: userpass
                                                             ('cccccccc-cccc-cccc-cccc-cccccccccccc', 'u3@acme.test', '{noop}userpass', 'User Three', 'USER');

-- INSERCIÓN DE PLANES DE SUSCRIPCIÓN (MOVIDO DESDE V1__init.sql)
insert into plans (id, code, name, price_cents, currency, interval_code, active) values
                                                                                     ('f0000000-0000-0000-0000-000000000001', 'BASIC', 'Básico', 999, 'EUR', 'MONTH', true),
                                                                                     ('f0000000-0000-0000-0000-000000000002', 'PREMIUM', 'Premium', 1999, 'EUR', 'MONTH', true);