-- src/main/resources/db/migration/V1__init.sql
-- Creación de la estructura de tablas inicial para todas las entidades del dominio.

-- USERS
create table if not exists users (
                                     id uuid primary key,
                                     email varchar(120) not null,
    password_hash varchar(120) not null,
    name varchar(60) not null,
    role varchar(20) not null,
    constraint uk_users_email unique(email)
    );

-- MOVIES
create table if not exists movies (
                                      id uuid primary key,
                                      title varchar(255) not null,
    overview varchar(4000),
    release_year integer,
    genres_csv varchar(255),
    tags_csv varchar(255),
    avg_rating float(53), -- Añadido en la entidad, debe estar en la tabla
    ratings_cnt integer   -- Añadido en la entidad, debe estar en la tabla
    );

-- RATINGS (PK compuesta)
create table if not exists ratings (
                                       movie_id uuid not null,
                                       user_id uuid not null,
                                       score integer not null,
                                       comment varchar(2000),
    ts timestamp with time zone not null,
                     primary key (movie_id, user_id),
    constraint fk_ratings_movie foreign key (movie_id) references movies(id),
    constraint fk_ratings_user  foreign key (user_id) references users(id)
    );

-- PLANS (Soluciona el error del PlansSeeder)
create table if not exists plans (
                                     id uuid primary key,
                                     code varchar(40) not null unique,
    name varchar(120) not null,
    price_cents integer not null,
    currency varchar(10) not null,
    interval_code varchar(20) not null,
    active boolean not null
    );

-- SUBSCRIPTIONS
create table if not exists subscriptions (
                                             id uuid primary key,
                                             user_id uuid not null,
                                             plan_id uuid not null,
                                             status varchar(20) not null, -- ACTIVE, CANCELED, EXPIRED
    started_at timestamp with time zone not null,
    ends_at timestamp with time zone not null,
    cancel_at timestamp with time zone,
                            constraint uk_sub_user unique (user_id),
    constraint fk_sub_plan foreign key (plan_id) references plans(id)
    );

-- INVOICES
create table if not exists invoices (
                                        id uuid primary key,
                                        user_id uuid not null,
                                        plan_code varchar(40) not null,
    amount_cents integer not null,
    currency varchar(10) not null,
    status varchar(20) not null,
    created_at timestamp with time zone not null,
    period_start timestamp with time zone not null,
    period_end timestamp with time zone not null
                             );

-- EVENTS (Para auditoría de administrador)
create table if not exists events (
                                      id uuid primary key,
                                      admin_id uuid not null,
                                      movie_id uuid,
                                      type varchar(40) not null,
    ts timestamp with time zone not null,
                     detail varchar(4000)
    );

