-- V2__seed.sql

-- 1. ASEGURAR QUE LA COLUMNA EXISTE
ALTER TABLE movies ADD COLUMN IF NOT EXISTS poster_url VARCHAR(1000);

-- 2. LIMPIEZA
DELETE FROM ratings;
DELETE FROM movies;

-- 3. INSERTAR PELÍCULAS (Con posters)
INSERT INTO movies (id, title, overview, genres_csv, tags_csv, release_year, avg_rating, ratings_cnt, poster_url) VALUES

-- CIENCIA FICCIÓN & CLÁSICOS
('00000000-0000-0000-0000-000000000101', 'The Matrix', 'Un hacker descubre la realidad simulada.', 'Ciencia Ficción,Acción', 'hacker,simulacion,ia', 1999, 4.3, 25000, 'https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg'),
('00000000-0000-0000-0000-000000000102', 'Inception', 'Ladrones de sueños.', 'Ciencia Ficción,Thriller', 'suenos,mente,nolan', 2010, 4.4, 31000, 'https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg'),
('00000000-0000-0000-0000-000000000103', 'Interstellar', 'Viaje a través de agujeros de gusano.', 'Ciencia Ficción,Drama', 'espacio,tiempo', 2014, 4.3, 28000, 'https://image.tmdb.org/t/p/w500/gEU2QniL6E8ahDaX06e8q288UL.jpg'),
('00000000-0000-0000-0000-000000000104', 'Toy Story', 'Juguetes que cobran vida.', 'Animación,Familiar', 'pixar,juguetes', 1995, 4.1, 19000, 'https://image.tmdb.org/t/p/w500/uXDfjJbdP4ijW5hWSBrPrlKpxab.jpg'),
('00000000-0000-0000-0000-000000000105', 'El Padrino', 'La familia Corleone.', 'Crimen,Drama', 'mafia,clasico', 1972, 4.6, 45000, 'https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsRolD1fZdja1.jpg'),
('00000000-0000-0000-0000-000000000106', 'El Viaje de Chihiro', 'Una niña en un mundo de espíritus.', 'Animación,Fantasía', 'ghibli,anime', 2001, 4.3, 21000, 'https://image.tmdb.org/t/p/w500/vlOaxsPEXSvrKwWeWHvTQ7RNSGh.jpg'),
('00000000-0000-0000-0000-000000000107', 'Alien', 'Terror en el espacio.', 'Terror,Ciencia Ficción', 'alien,espacio', 1979, 4.2, 18000, 'https://image.tmdb.org/t/p/w500/vfrQk5IPloGg1v9Rzbh2Eg3VGyM.jpg'),
('00000000-0000-0000-0000-000000000108', 'Blade Runner', 'Cazador de androides.', 'Ciencia Ficción,Noir', 'cyberpunk,futuro', 1982, 4.0, 16500, 'https://image.tmdb.org/t/p/w500/63N9uy8nd9j7Eog2seLZNdnbKmt.jpg'),

-- ÉXITOS
('00000000-0000-0000-0000-000000000109', 'El Caballero Oscuro', 'Batman vs Joker.', 'Acción,Crimen', 'batman,joker', 2008, 4.5, 52000, 'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg'),
('00000000-0000-0000-0000-000000000110', 'Pulp Fiction', 'Historias de crimen entrelazadas.', 'Crimen,Drama', 'tarantino,culto', 1994, 4.4, 41000, 'https://image.tmdb.org/t/p/w500/d5iIlFn5s0ImszYzBPb8JPIfbXD.jpg'),
('00000000-0000-0000-0000-000000000111', 'Cadena Perpetua', 'Esperanza en prisión.', 'Drama', 'prision,amistad', 1994, 4.6, 60000, 'https://image.tmdb.org/t/p/w500/q6y0Go1tsGEsmtFryDOJo3dEmqu.jpg'),
('00000000-0000-0000-0000-000000000112', 'Forrest Gump', 'La vida es como una caja de bombones.', 'Drama,Romance', 'tomhanks,historia', 1994, 4.4, 38000, 'https://image.tmdb.org/t/p/w500/saHP97rTPS5eLmrLQEcANmKrsFl.jpg'),
('00000000-0000-0000-0000-000000000113', 'Jurassic Park', 'Dinosaurios vuelven a la vida.', 'Aventura,Ciencia Ficción', 'dinos,spielberg', 1993, 4.1, 29000, 'https://image.tmdb.org/t/p/w500/oU7Oq2kFAAlGqbU4VoAE36g4hoI.jpg'),
('00000000-0000-0000-0000-000000000114', 'Vengadores: Endgame', 'La batalla final contra Thanos.', 'Acción,Aventura', 'marvel,thanos', 2019, 4.2, 45000, 'https://image.tmdb.org/t/p/w500/br66a35Y6V3d4YVN57497Gf0v4Q.jpg'),
('00000000-0000-0000-0000-000000000115', 'Titanic', 'Un romance en el barco inhundible.', 'Romance,Drama', 'dicaprio,barco', 1997, 3.9, 35000, 'https://image.tmdb.org/t/p/w500/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg'),
('00000000-0000-0000-0000-000000000116', 'Psicosis', 'Un motel peligroso.', 'Terror,Thriller', 'hitchcock,blanco_y_negro', 1960, 4.2, 15000, 'https://image.tmdb.org/t/p/w500/3cxrAyCXWAAgDb6af524os3vXjo.jpg'),
('00000000-0000-0000-0000-000000000117', 'El Señor de los Anillos', 'El retorno del Rey.', 'Fantasía,Aventura', 'anillo,epico', 2003, 4.5, 48000, 'https://image.tmdb.org/t/p/w500/mWuFB30pwbv6rC6uPqE8yT1J0L5.jpg'),
('00000000-0000-0000-0000-000000000118', 'Star Wars IV', 'Una nueva esperanza.', 'Ciencia Ficción,Aventura', 'jedi,espacio', 1977, 4.3, 42000, 'https://image.tmdb.org/t/p/w500/6FfCtAuVAW8XJjZ7eWeLibRLWTw.jpg'),
('00000000-0000-0000-0000-000000000119', 'El Rey León', 'El ciclo de la vida.', 'Animación,Musical', 'disney,leones', 1994, 4.2, 33000, 'https://image.tmdb.org/t/p/w500/b0MxUcaDIgHanPp7gYUsD967B0c.jpg'),
('00000000-0000-0000-0000-000000000120', 'El Silencio de los Corderos', 'Hannibal Lecter ayuda al FBI.', 'Thriller,Crimen', 'hannibal,miedo', 1991, 4.3, 27000, 'https://image.tmdb.org/t/p/w500/rplLJ2hPcOQmkFhTqUte0MkEaO2.jpg'),
('00000000-0000-0000-0000-000000000121', 'El Club de la Lucha', 'Regla 1: No hablar del club.', 'Drama', 'fincher,bradpitt', 1999, 4.4, 36000, 'https://image.tmdb.org/t/p/w500/1y85qqfA59E7d5z9d8v8q2y7z9d.jpg'),
('00000000-0000-0000-0000-000000000122', 'Parásitos', 'Dos familias, dos mundos.', 'Thriller,Drama', 'korea,oscar', 2019, 4.2, 24000, 'https://image.tmdb.org/t/p/w500/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg'),
('00000000-0000-0000-0000-000000000123', 'Gladiator', 'El general que se convirtió en esclavo.', 'Acción,Drama', 'roma,maximus', 2000, 4.2, 31000, 'https://image.tmdb.org/t/p/w500/ty8TGRuvJLPUmAR1H1nRIsgwvim.jpg'),
('00000000-0000-0000-0000-000000000124', 'Regreso al Futuro', 'Marty McFly viaja a 1955.', 'Ciencia Ficción,Comedia', 'delorean,80s', 1985, 4.2, 34000, 'https://image.tmdb.org/t/p/w500/fNOH9f1aA7XRTzl1sAQL9QBIdIP.jpg'),
('00000000-0000-0000-0000-000000000125', 'Coco', 'El día de los muertos.', 'Animación,Fantasía', 'pixar,musica', 2017, 4.2, 18000, 'https://image.tmdb.org/t/p/w500/eKi8dIrr8voB6sYz2DjJYLp9D71.jpg'),
('00000000-0000-0000-0000-000000000126', 'El Resplandor', 'Aquí está Johnny.', 'Terror', 'hotel,kubrick', 1980, 4.2, 22000, 'https://image.tmdb.org/t/p/w500/9fgh3Ns1iRzlQPYuoJyTkyY1Up.jpg'),
('00000000-0000-0000-0000-000000000127', 'WALL·E', 'Un robot limpia la Tierra.', 'Animación,Ciencia Ficción', 'pixar,robot', 2008, 4.2, 20000, 'https://image.tmdb.org/t/p/w500/hceosugMsDob96E875f561y7bXp.jpg'),
('00000000-0000-0000-0000-000000000128', 'La La Land', 'Ciudad de las estrellas.', 'Romance,Musical', 'baile,hollywood', 2016, 4.0, 16000, 'https://image.tmdb.org/t/p/w500/uDO8zWDhfWwoUyBab2PYFdB9Ibd.jpg'),
('00000000-0000-0000-0000-000000000130', 'Salvar al Soldado Ryan', 'La misión tras el desembarco.', 'Guerra,Drama', 'ww2,spielberg', 1998, 4.3, 29000, 'https://image.tmdb.org/t/p/w500/1wY4psJ5NVEhCuDgmE9usl8y0.jpg'),
('00000000-0000-0000-0000-000000000131', 'Spider-Man', 'Un Nuevo Universo.', 'Animación,Acción', 'milesmorales,marvel', 2018, 4.2, 17000, 'https://image.tmdb.org/t/p/w500/iiZZdoQBEYBv6id8su7ImL0oCbD.jpg'),
('00000000-0000-0000-0000-000000000132', 'Seven', 'Siete pecados capitales.', 'Crimen,Thriller', 'fincher,misterio', 1995, 4.3, 28000, 'https://image.tmdb.org/t/p/w500/6y0G4uxp8ns1e83W6956W8M1uea.jpg'),
('00000000-0000-0000-0000-000000000133', 'La Lista de Schindler', 'El que salva una vida salva al mundo.', 'Drama,Historia', 'holocausto,spielberg', 1993, 4.5, 32000, 'https://image.tmdb.org/t/p/w500/c8Ass7acuOe4za6FyQHbuwVLqyH.jpg'),
('00000000-0000-0000-0000-000000000139', 'Harry Potter 1', 'La piedra filosofal.', 'Fantasía,Aventura', 'magia,hogwarts', 2001, 3.8, 38000, 'https://image.tmdb.org/t/p/w500/wuMc08IPKEatf9rnMNXvIDxqP4W.jpg'),
('00000000-0000-0000-0000-000000000140', 'Avatar', 'Pandora te espera.', 'Ciencia Ficción,Aventura', 'cameron,3d', 2009, 3.9, 31000, 'https://image.tmdb.org/t/p/w500/6EiRUJolstS4QN9ofYbBuwXDqBc.jpg');


-- 4. INSERTAR VALORACIONES (¡Esta línea era la que faltaba!)
INSERT INTO ratings (movie_id, user_id, score, comment, ts) VALUES

-- Valoraciones para "El Caballero Oscuro" (ID ...109)
('00000000-0000-0000-0000-000000000109', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 5, 'La mejor película de superhéroes de la historia.', current_timestamp),

-- Valoraciones para "Jurassic Park" (ID ...113)
('00000000-0000-0000-0000-000000000113', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 4, 'Los efectos siguen viéndose increíbles.', current_timestamp),

-- Valoraciones para "Pulp Fiction" (ID ...110)
('00000000-0000-0000-0000-000000000110', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 5, 'Diálogos brillantes, Tarantino es un genio.', current_timestamp),

-- Valoraciones para "Cadena Perpetua" (ID ...111)
('00000000-0000-0000-0000-000000000111', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 4, 'Muy emotiva, un clásico instantáneo.', current_timestamp),

-- Valoraciones para "Forrest Gump" (ID ...112)
('00000000-0000-0000-0000-000000000112', 'cccccccc-cccc-cccc-cccc-cccccccccccc', 5, 'Corre Forrest, corre! Obra maestra.', current_timestamp),

-- Valoraciones para "Matrix" (ID ...101)
('00000000-0000-0000-0000-000000000101', 'cccccccc-cccc-cccc-cccc-cccccccccccc', 5, 'Me voló la cabeza la primera vez que la vi.', current_timestamp);